from .models import MedicalReport
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import MedicalReportSerializer
from .models import MedicalReport
from rest_framework import generics
from .serializers import MedicalReportSerializer


class UploadFileView(generics.CreateAPIView):
    queryset = MedicalReport.objects.all()
    serializer_class = MedicalReportSerializer


class GetFileListView(generics.ListAPIView):
    queryset = MedicalReport.objects.all()
    serializer_class = MedicalReportSerializer


class GetFileView(generics.RetrieveAPIView):
    queryset = MedicalReport.objects.all()
    serializer_class = MedicalReportSerializer
    # lookup_field = "report_id"

    # def get(self, request, *args, **kwargs):

    #     report_id = self.kwargs.get("pk")
    #     report = MedicalReport.objects.get(id=report_id)
    #     report.report_file.path = report.report_file.path.replace(
    #         "http://localhost:8000/", "https://2d8lz4pf-8000.inc1.devtunnels.ms/")
    #     report.save()
    #     serializer = MedicalReportSerializer(report)
    #     return Response(serializer.data)
